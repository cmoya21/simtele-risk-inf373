import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { createSqliteStore } from './store-core.mjs';

export function createStore(path) {
  if (path !== ':memory:') mkdirSync(dirname(path), {recursive:true});
  const db = new DatabaseSync(path);
  try {
    db.exec('PRAGMA busy_timeout = 3000; PRAGMA journal_mode = WAL;');
    return createSqliteStore(db, readFileSync(new URL('./schema.sql', import.meta.url),'utf8'), randomUUID);
  } catch (error) {
    db.close();
    throw error;
  }
}
