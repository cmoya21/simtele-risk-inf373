import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, unlinkSync, rmdirSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { createStore } from '../store.mjs';
import { cases } from '../math.mjs';

test('SQLite conserva los 12 experimentos tras cerrar, reabrir y relanzar', () => {
  const dir=mkdtempSync(fileURLToPath(new URL('../.test-db-',import.meta.url)));
  const path=join(dir,'prueba.sqlite');
  let store;
  try {
    store=createStore(path);
    const saved=cases.flatMap(c=>Object.keys(c.scenarios).map(s=>store.execute(c.id,s,{})));
    assert.equal(saved.length,12);
    store.close();
    store=createStore(path);
    assert.equal(store.list().length,12);
    assert.equal(store.list(saved[0].id).length,1);
    for(const record of saved) {
      const recovered=store.open(record.id);
      assert.deepEqual(recovered, JSON.parse(JSON.stringify(record)));
      assert.ok(recovered.result.charts.length>=2);
      assert.ok(recovered.result.methods.some(m=>m.iterations.length>0));
      const replay=store.repeat(record.id);
      assert.ok(replay.verification.matched, JSON.stringify(replay.verification));
      assert.equal(replay.verification.maxDelta,0);
    }
    store.close();
    store=null;
    const db=new DatabaseSync(path,{readOnly:true});
    try {
      assert.equal(db.prepare('SELECT count(*) AS n FROM caso_estudio').get().n,4);
      assert.equal(db.prepare('SELECT count(*) AS n FROM escenario').get().n,12);
      assert.equal(db.prepare('SELECT count(*) AS n FROM simulacion').get().n,24);
      assert.equal(db.prepare('SELECT count(*) AS n FROM simulacion WHERE repeticion_de IS NOT NULL').get().n,12);
      assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(),[]);
      assert.ok(db.prepare('SELECT count(*) AS n FROM iteracion_resultado').get().n>0);
      assert.equal(db.prepare('SELECT count(*) AS n FROM ejecucion_metodo').get().n,
        db.prepare('SELECT count(*) AS n FROM resultado_resumen').get().n);
    } finally { db.close(); }
  } finally {
    store?.close();
    for(const file of [path,path+'-wal',path+'-shm']) if(existsSync(file)) unlinkSync(file);
    rmdirSync(dir);
  }
});
