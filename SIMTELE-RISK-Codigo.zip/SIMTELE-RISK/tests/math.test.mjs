import assert from 'node:assert/strict';
import test from 'node:test';
import { cases, run } from '../math.mjs';

const close = (got, expected, tolerance) =>
  assert.ok(Math.abs(got - expected) <= tolerance, `Obtuve ${got}; esperado ${expected} ± ${tolerance}`);
const match = (result, prefix) => result.methods.find(m => m.name.startsWith(prefix));

test('Los 12 escenarios producen trazas, referencias, comparación y JSON sin números inválidos', () => {
  let count = 0;
  function checkFinite(value) {
    if (typeof value === 'number') assert.ok(Number.isFinite(value));
    else if (value && typeof value === 'object') Object.values(value).forEach(checkFinite);
    else assert.notEqual(value, undefined);
  }
  for (const c of cases) {
    assert.equal(Object.keys(c.scenarios).length, 3);
    for (const scenario of Object.keys(c.scenarios)) {
      const result = run(c.id, scenario);
      checkFinite(result);
      assert.deepEqual(JSON.parse(JSON.stringify(result)), result);
      assert.ok(result.charts.length >= 2);
      assert.ok(result.methods.every(m => m.iterations.length > 0 && m.settings.stop));
      assert.ok(result.sensitivity.length);
      assert.deepEqual(run(c.id, scenario, result.params), result);
      count++;
    }
  }
  assert.equal(count, 12);
});

test('Frenado constante: distancia, parada, referencia RK y cuadraturas reproducen solución manual', () => {
  const r = run('detencion', 'normal', { v0: 6, reaction: 1, brake: 2, slope: 0, drag: 0 });
  close(r.reference.frenado_s, 3, 1e-14);
  close(r.reference.frenado_m, 9, 1e-14);
  close(r.reference.detencion_total_m, 15, 1e-14);
  for (const m of r.methods) {
    if (m.settings.unit === 's') close(m.value, 3, 1e-8);
    else close(m.value, 9, 1e-11);
    assert.equal(m.converged, true);
  }
});

test('Frenado con arrastre: los tres métodos de raíces encuentran la parada; RK4 y Simpson reducen error', () => {
  const r = run('detencion', 'estres');
  for (const name of ['Bisección', 'Newton-Raphson', 'Secante']) {
    const m = match(r, name);
    close(m.value, Math.log(2.2) / .12, 1e-8);
    assert.ok(m.converged && m.residual < 1e-8);
  }
  assert.ok(match(r, 'RK4').errorAbs < match(r, 'RK2').errorAbs / 100);
  assert.ok(match(r, 'Simpson').errorAbs < match(r, 'Trapecio').errorAbs / 100);
  assert.ok(match(r, 'Romberg').errorAbs < 1e-8);
});

test('Cancelación de desaceleraciones amplifica cambios sin impedir convergencia', () => {
  const r = run('detencion', 'mal');
  close(r.reference.frenado_s, 400, 1e-9);
  close(r.details.condicion_relativa_del_tiempo_respecto_a_freno, 201, 1e-8);
  assert.ok(r.sensitivity[0].amplification > 190);
  assert.ok(r.methods.every(m => m.converged));
});

test('Raíz de deterioro cuadrática verificable en t=10 y solución SPD conocida', () => {
  const r = run('deterioro', 'normal', { d0: .1, alpha: .02, beta: .001, threshold: .4 });
  close(r.reference.umbral_dias, 10, 1e-12);
  for (const m of r.methods.slice(0, 3)) close(m.value, 10, 1e-7);
  for (const m of r.methods.slice(3)) {
    assert.ok(m.converged);
    assert.ok(m.errorAbs < 1e-9);
  }
  const A = r.details.matriz_A;
  A.forEach(row => close(row.reduce((sum, x) => sum + x, 0), r.params.epsilon, 1e-14));
});

test('Calibración débil: régimen SPD, iteraciones estacionarias limitadas y amplificación cuantificada', () => {
  const r = run('deterioro', 'mal');
  close(r.reference.condicion_2, 1e7, 1e-8);
  assert.ok(r.details.radio_espectral_jacobi < 1);
  assert.equal(match(r, 'Jacobi').converged, false);
  assert.equal(match(r, 'Gauss-Seidel').converged, false);
  assert.ok(match(r, 'LU').errorAbs < 1e-8);
  assert.ok(match(r, 'Gradiente').errorAbs < 1e-8);
  close(r.sensitivity[1].deltaOutput / r.sensitivity[1].deltaInput, 1e7, 1e-7);
});

test('Viento: los órdenes observados de RK2 y RK4 mejoran con dos mallas y J tiene referencia independiente', () => {
  const coarse = run('viento', 'normal', { steps: 96 });
  const fine = run('viento', 'normal', { steps: 192 });
  const rate = name => match(coarse, name).settings.maxErrorPosition / match(fine, name).settings.maxErrorPosition;
  assert.ok(rate('RK2') > 3.5 && rate('RK2') < 4.5);
  assert.ok(rate('RK4') > 14 && rate('RK4') < 18);
  assert.ok(coarse.details.discrepancia_referencia_J < 1e-13);
  assert.ok(match(coarse, 'Romberg').errorAbs < 1e-10);
  // For v0 = -d*x0, the exact free motion is x0*exp(-dt)*cos(wd*t).
  // Integrate cos² using its double-angle identity as an independent oracle.
  const d = .15, x0 = .3, end = 16, a = -2 * d, b = 2 * Math.sqrt(1.6 - d * d);
  const primitive = t => Math.exp(a * t) * (a * Math.cos(b * t) + b * Math.sin(b * t)) / (a * a + b * b);
  const exactIntegral = x0 * x0 * (Math.expm1(a * end) / a + primitive(end) - primitive(0)) / 2;
  const simple = run('viento', 'normal', { v0: -d * x0 });
  close(simple.reference.J_m2_s, exactIntegral, 2e-14);
  const unstable = run('viento', 'estres', { steps: 4 });
  assert.ok(match(unstable, 'RK4').settings.factorEstabilidadHomogenea > 1);
  assert.equal(match(unstable, 'RK4').converged, false);
});

test('Viento: excitación cerca de resonancia y cero exacto sin error relativo', () => {
  const r = run('viento', 'mal');
  assert.ok(r.details.condicion_frecuencia_amplitud > 300);
  assert.ok(r.reference.amplitud_estacionaria_m > r.reference.pico_m_malla_2048);
  const zero = run('viento', 'normal', { x0: 0, v0: 0, force: 0 });
  assert.ok(zero.methods.every(m => m.value === 0 && m.errorRel === null && m.errorPct === null));
});

test('Sensores: mismos nodos, verificación sobre puntos omitidos y ganancia de Lebesgue', () => {
  const r = run('sensores', 'mal');
  const [lagrange, newton, spline] = r.methods;
  close(lagrange.value, newton.value, 1e-8);
  assert.ok(lagrange.value > 10 && spline.value < .03);
  assert.ok(r.sensitivity[0].amplification > 1e5);
  assert.ok(r.sensitivity[2].amplification < 4);
  for (const s of r.sensitivity) close(s.amplification / s.constante_Lebesgue_en_prueba, 1, 1e-7);
  for (const [t, v] of r.reference.ocultos) {
    assert.ok(!r.reference.nodos.includes(t));
    close(v, Math.sin(t), 1e-14);
  }
  for (const m of r.methods) assert.ok(m.residual <= 1e-7);
});

test('Validación: sin coerción de blancos, parámetros no identificados ni estados fuera del dominio', () => {
  assert.throws(() => run('sensores', 'normal', { nodes: '' }), /Número de nodos/);
  assert.throws(() => run('sensores', 'normal', { nodes: 5.5 }), /entero/);
  assert.throws(() => run('sensores', 'normal', { random: 1 }), /desconocido/);
  assert.throws(() => run('detencion', 'normal', { brake: 1, slope: 1 }), /debe superar/);
  assert.throws(() => run('deterioro', 'normal', { d0: .9, threshold: .7 }), /umbral/);
  assert.throws(() => run('viento', 'normal', { mass: 100, stiffness: 100, damping: 500 }), /subamortiguado/);
});
