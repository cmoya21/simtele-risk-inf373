# SIMTELE-RISK

Proyecto integrador de **INF 373 · Métodos Numéricos**  
**Carlos Angel Moya Choque y Dante Pabel Churata Apaza** · Lic. Brigida Alexandra Carvajal Blanco  
Universidad Mayor de San Andrés · FCPN · Carrera de Informática · Mención Desarrollo de Software

Laboratorio de simulación con cuatro casos inspirados en el transporte por cable de La Paz.
Todos los parámetros y registros son sintéticos. La aplicación es académica y no controla equipos reales.

## Inicio rápido

Requisito: **Node.js 24 o superior**. La aplicación no necesita descargar dependencias de npm.

```powershell
node server.mjs
```

También puedes abrir **Iniciar_SIMTELE.cmd** en Windows. Abre [http://127.0.0.1:8765/](http://127.0.0.1:8765/).
La base se crea al iniciar en `data/simtele.sqlite`. Mantén la consola abierta mientras usas la web.

```powershell
node --test tests/*.test.mjs
```

## Casos

| Caso | Métodos principales | Experimento de sensibilidad |
| --- | --- | --- |
| Detención | RK2 (punto medio), RK4, trapecio, Simpson, Romberg, bisección, Newton-Raphson, secante | Desaceleración neta pequeña por cancelación de aportes |
| Deterioro | Bisección, Newton-Raphson, secante, Jacobi, Gauss-Seidel, LU y gradiente conjugado | Calibración SPD con condición elevada |
| Oscilaciones por viento | RK2, RK4, trapecio, Simpson y Romberg | Sensibilidad de la respuesta estacionaria cerca de resonancia |
| Sensores | Lagrange, Newton por diferencias divididas y spline cúbico | Nodos agrupados y amplificación del ruido |

Cada caso ofrece NORMAL, ESTRÉS y MAL CONDICIONADO. Los parámetros de ejemplo se encuentran en el
catálogo exportado por `math.mjs` y se cargan automáticamente al elegir el escenario.
Las comparaciones usan las mismas unidades dentro de cada método. El error relativo se omite cuando su referencia es cero.
La condición cuantifica la sensibilidad de los datos. La convergencia y el riesgo modelado se evalúan por separado.

## Guardar y repetir

1. Abre un caso y selecciona un escenario. Ajusta un parámetro dentro del rango mostrado y ejecuta.
2. Guarda la simulación y abre **Historial**. Identifícala por caso, escenario o ID.
3. Detén y vuelve a iniciar el servidor con la misma ruta de base de datos.
4. Abre el registro. Comprueba que aparecen parámetros, resultados, gráficos e iteraciones.
5. Pulsa **Relanzar**. Se guarda otra ejecución con el resultado de comparar el árbol numérico y sus metadatos.

El [DER y modelo relacional](docs/DER.md) documentan las seis entidades. [schema.sql](schema.sql) define
tablas, claves, relaciones y restricciones. [La prueba de persistencia](tests/persistencia.test.mjs)
realiza ese ciclo con los doce escenarios y comprueba las claves foráneas y las tablas normalizadas.

## Despliegue con almacenamiento persistente

```sh
docker build -t simtele-risk .
docker run --name simtele-risk -p 8765:8765 -v simtele-data:/app/data simtele-risk
```

Para alojamiento, configura `PORT`, `SIMTELE_HOST=0.0.0.0` y `SIMTELE_DB` apuntando a un volumen persistente.
El servicio está pensado para demostraciones académicas en un entorno con acceso controlado.
En GitHub Pages se usa el mismo esquema y motor SQLite con sql.js 1.14.2. IndexedDB conserva el archivo SQLite por navegador y origen. En esta modalidad cada navegador tiene su propio historial.

Ejecuta `node scripts/preparar-pages.mjs` para generar la carpeta estática `dist/`.

## Defensa

Prueba una velocidad inicial distinta en Detención, recupera el experimento del historial y vuelve a correrlo.
Explica por qué un residuo pequeño puede coexistir con un error de solución apreciable, y qué distingue
el error de interpolación de la sensibilidad a ruido. Desde Desarrollo de Software, muestra el contrato
de la API, la transacción y la prueba reproducible de recuperación.
