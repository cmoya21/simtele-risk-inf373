# Modelo de datos de SIMTELE-RISK

```mermaid
erDiagram
    caso_estudio ||--o{ escenario : define
    escenario ||--o{ simulacion : parametriza
    simulacion ||--o{ ejecucion_metodo : ejecuta
    simulacion o|--o{ simulacion : antecede
    ejecucion_metodo ||--o{ iteracion_resultado : registra
    ejecucion_metodo ||--|| resultado_resumen : resume
    caso_estudio {
      text id PK
      text nombre
      text modelo_version
    }
    escenario {
      int id PK
      text caso_id FK
      text tipo
      json parametros_json
      text fuente_datos
    }
    simulacion {
      text id PK
      int escenario_id FK
      text fecha
      text usuario
      text estado
      text version_motor
      json resultado_json
      text repeticion_de FK
      json verificacion_json
    }
    ejecucion_metodo {
      int id PK
      text simulacion_id FK
      text metodo
      real tolerancia
      real paso
      int max_iter
      boolean convergio
      real tiempo_ms
      json configuracion_json
    }
    iteracion_resultado {
      int ejecucion_id PK,FK
      int numero PK
      json aproximacion_json
      real residual
      real error_abs
      real error_rel
      json registro_json
    }
    resultado_resumen {
      int ejecucion_id PK,FK
      json referencia
      json valor_json
      json metrica_error_json
      text interpretacion
    }
```

Cada combinación de caso, escenario y parámetros efectivos identifica una configuración reutilizable.
Una simulación almacena el resultado integral y una copia normalizada de los métodos, sus iteraciones y sus métricas.
El resultado integral conserva gráficos, sensibilidad y conclusiones tal como se presentaron, aunque cambie el motor.
Una transacción garantiza que se guarden juntos el resultado integral y los registros normalizados.
Al relanzar se ejecuta el motor sobre los parámetros archivados, se registra la nueva simulación y se compara el árbol de resultados.
La prueba usa la cota `|a-b| ≤ 1e-10 × max(1, |a|, |b|)` y comprueba también la estructura y los datos no numéricos.
`NULL` significa que la métrica no corresponde o no está definida. El tiempo de método es opcional.
