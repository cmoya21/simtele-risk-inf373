"""Informes reproducibles de SIMTELE-RISK. Requiere ReportLab y el JSON exportado."""
import argparse
import itertools
import json
import math
import os
import re
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Flowable, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)

ROOT = Path(__file__).resolve().parents[1]
FONT_DIR = Path(os.getenv("WINDIR", "C:/Windows")) / "Fonts"
if not (FONT_DIR / "segoeui.ttf").is_file():
    FONT_DIR = Path("/usr/share/fonts/truetype/dejavu")
    fonts = ("DejaVuSans.ttf", "DejaVuSans-Bold.ttf")
else:
    fonts = ("segoeui.ttf", "segoeuib.ttf")
for name, file in zip(("Body", "BodyBold"), fonts):
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR / file)))
pdfmetrics.registerFontFamily("Body", normal="Body", bold="BodyBold")
NAVY = colors.HexColor("#0d2c3e")
TEAL = colors.HexColor("#006f70")
GRAY = colors.HexColor("#4c626b")
FAINT = colors.HexColor("#e8f1f2")
LINE = colors.HexColor("#c8d8de")
INK = colors.HexColor("#132e38")
GOLD = colors.HexColor("#f2bb78")
WHITE = colors.white
PLOT = ["#005f77", "#a94115", "#007358", "#6c388b", "#8e5810", "#2e527e", "#4c626b"]
CASES = ("detencion", "deterioro", "viento", "sensores")
SCENARIOS = ("normal", "estres", "mal")
S_LABEL = {"normal": "Normal", "estres": "Estrés", "mal": "Mal condicionado"}
STUDENT = "Carlos Angel Moya Choque"
TEACHER = "Lic. Brigida Alexandra Carvajal Blanco"
W, H = A4
BODY_WIDTH = W - 96

def style(name, size, lead, color=INK, bold=False, before=0, after=0):
    return ParagraphStyle(
        name, fontName="BodyBold" if bold else "Body", fontSize=size, leading=lead,
        textColor=color, spaceBefore=before, spaceAfter=after,
    )

P = style("body", 10.2, 14.8, after=7)
SMALL = style("small", 8.5, 11.8, GRAY, after=6)
H1 = style("h1", 23, 28, NAVY, True, after=12)
H2 = style("h2", 12, 15, TEAL, True, before=8, after=5)
LABEL = style("label", 8.6, 11, TEAL, True, after=7)
CELL = style("cell", 8.1, 10.4)
HEAD = style("head", 8.1, 10.4, WHITE, True)
FORMULA = style("formula", 10, 15, NAVY, True)

def esc(value):
    return escape(str(value)).replace("–", "-").replace("—", "-").replace("‑", "-")

def fmt(value, digits=5):
    if value is None: return "n/a"
    if isinstance(value, bool): return "Sí" if value else "No"
    if isinstance(value, (int, float)):
        if not math.isfinite(value): return "n/a"
        if value == 0: return "0"
        if abs(value) < 1e-3 or abs(value) >= 1e5:
            return f"{value:.{max(2,digits-2)}e}"
        return f"{value:.{digits}g}"
    if isinstance(value, list):
        return "[" + "; ".join(fmt(v, digits) for v in value[:8]) + (", …" if len(value)>8 else "") + "]"
    if isinstance(value, dict):
        return ", ".join(f"{k}={fmt(v, digits)}" for k,v in list(value.items())[:5])
    return str(value)

def para(t, s=P):
    return Paragraph(esc(t).replace("\n","<br/>"), s)

def table(head, rows, weights=None):
    n=len(head)
    weights=weights or [1]*n
    tb=Table(
        [[para(x,HEAD) for x in head]]+[[para(x,CELL) for x in row] for row in rows],
        colWidths=[BODY_WIDTH*x/sum(weights) for x in weights], repeatRows=1, hAlign="LEFT",
    )
    tb.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),("VALIGN",(0,0),(-1,-1),"TOP"),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,FAINT]),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LINEBELOW",(0,-1),(-1,-1),.55,LINE),
    ]))
    return tb

def equation(t):
    tb=Table([[para(t,FORMULA)]],colWidths=[BODY_WIDTH])
    tb.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),FAINT),
                            ("BOX",(0,0),(-1,-1),.45,LINE),
                            ("LEFTPADDING",(0,0),(-1,-1),10),
                            ("TOPPADDING",(0,0),(-1,-1),6),
                            ("BOTTOMPADDING",(0,0),(-1,-1),6)]))
    return tb

class Plot(Flowable):
    def __init__(self, chart, height=169):
        super().__init__()
        self.width=BODY_WIDTH
        self.height=height
        self.chart=chart

    def draw(self):
        c=self.canv
        ch=self.chart
        series=[]
        for s in ch.get("series",[]):
            points=[p for p in s.get("points",[]) if isinstance(p,(list,tuple)) and len(p)>=2 and all(isinstance(v,(int,float)) and math.isfinite(v) for v in p[:2])]
            if points: series.append((s.get("label",""),points,s.get("markersOnly",False)))
        c.setFillColor(FAINT)
        c.roundRect(0,0,self.width,self.height,8,fill=1,stroke=0)
        c.setFont("BodyBold",9)
        c.setFillColor(NAVY)
        c.drawString(13,self.height-17,str(ch.get("title","Gráfico de resultados"))[:90])
        if not series:
            c.setFont("Body",8); c.drawString(14,40,"Sin valores finitos en esta ejecución.")
            return
        L,R=63,self.width-17
        B,T=48,self.height-38
        points=[p for _,s,_ in series for p in s]
        xl,xr=min(p[0] for p in points),max(p[0] for p in points)
        yl,yr=min(p[1] for p in points),max(p[1] for p in points)
        if xr==xl: xr=xl+1
        if yr==yl:
            pad=1 if yr==0 else abs(yr)*.15
            yl-=pad;yr+=pad
        py=lambda y:B+(y-yl)*(T-B)/(yr-yl)
        px=lambda x:L+(x-xl)*(R-L)/(xr-xl)
        c.setFont("Body",6.9)
        c.setStrokeColor(LINE)
        c.setFillColor(GRAY)
        c.drawString(13,T+8,str(ch.get("yLabel","y"))[:50])
        for j in range(5):
            y=B+j*(T-B)/4
            x=L+j*(R-L)/4
            c.setStrokeColor(LINE);c.setLineWidth(.45)
            c.line(L,y,R,y);c.line(x,B,x,T)
            c.drawRightString(L-5,y-2.3,fmt(yl+j*(yr-yl)/4,3))
            c.drawCentredString(x,B-10,fmt(xl+j*(xr-xl)/4,3))
        c.setFillColor(GRAY)
        c.drawCentredString((L+R)/2,B-21,str(ch.get("xLabel","x"))[:62])
        for i,(label,pts,markers_only) in enumerate(series):
            col=colors.HexColor(PLOT[i%len(PLOT)])
            c.setStrokeColor(col)
            c.setFillColor(col)
            c.setLineWidth(1.25)
            if len(pts)>1 and not markers_only:
                pth=c.beginPath()
                pth.moveTo(px(pts[0][0]),py(pts[0][1]))
                for a,b,*_ in pts[1:]: pth.lineTo(px(a),py(b))
                if i>0 and i%2==0: c.setDash(3,2)
                c.drawPath(pth,stroke=1,fill=0)
                c.setDash()
            if len(pts)<=32 or markers_only:
                for a,b,*_ in pts: c.circle(px(a),py(b),1.8,stroke=0,fill=1)
            ncol=min(4,len(series))
            lx=13+(i%ncol)*(self.width-26)/ncol
            ly=20-(i//ncol)*10
            c.line(lx,ly+2,lx+11,ly+2)
            c.setFont("Body",6.7)
            c.drawString(lx+14,ly,shorten(label,25))

class DER(Flowable):
    def __init__(self):
        super().__init__()
        self.width=BODY_WIDTH
        self.height=229

    def draw(self):
        c=self.canv
        boxes=[
            (0,163,"caso_estudio","PK id · modelo_version"),
            (175,163,"escenario","FK caso_id · tipo · parámetros"),
            (350,163,"simulacion","FK escenario_id · fecha · estado"),
            (350,84,"ejecucion_metodo","FK simulacion_id · método"),
            (175,5,"iteracion_resultado","FK ejecucion_id · número"),
            (350,5,"resultado_resumen","FK ejecucion_id · métricas"),
        ]
        bw=self.width-350
        c.setStrokeColor(TEAL)
        c.setFillColor(TEAL)
        c.setFont("BodyBold",7.4)
        for x1,y1,x2,y2,card in [
            (bw,189,175,189,"1:N"),(175+bw,189,350,189,"1:N"),
            (425,163,425,137,"1:N"),(425,84,425,58,"1:1"),
            (350,108,250,108,"1:N"),(250,108,250,58,""),
        ]:
            c.line(x1,y1,x2,y2)
            if card:
                vertical=x1==x2
                c.drawCentredString((x1+x2)/2+(13 if vertical else 0),(y1+y2)/2+(1 if vertical else 5),card)
        for x,y,name,detail in boxes:
            c.setFillColor(FAINT); c.setStrokeColor(LINE)
            c.roundRect(x,y,bw,53,6,fill=1,stroke=1)
            c.setFillColor(NAVY);c.setFont("BodyBold",9.3)
            c.drawString(x+7,y+31,name)
            c.setFillColor(GRAY);c.setFont("Body",7.5)
            c.drawString(x+7,y+15,detail)

TITLE = {
    "detencion": "Detención de emergencia",
    "deterioro": "Deterioro y mantenimiento",
    "viento": "Oscilaciones por viento",
    "sensores": "Reconstrucción de sensores",
}
MODELS = {
    "detencion": (
        "¿Cómo cambian el tiempo y la distancia total si aumenta la velocidad inicial, se retrasa la reacción o se reduce el frenado efectivo?",
        "x′ = v;   v′ = −A − qv;   A = freno − pendiente;   x(0) = 0, v(0) = v₀.",
        "x en m, v en m/s, tiempo en s, frenado y pendiente equivalente en m/s² y q en s⁻¹. Durante la reacción se conserva v₀. La fase de frenado comienza al final de la reacción. Los parámetros son hipótesis sintéticas.",
        "Si q = 0, v(t) = v₀ − At y x(t) = v₀t − At²/2. Si q > 0, v(t) = (v₀ + A/q)e⁻ᵖ − A/q, con p = qt. La parada ocurre en log(1 + qv₀/A)/q. Distancia total = v₀ · reacción + integral de v durante el frenado.",
        "En estrés se comparan una condición de operación más exigente y los efectos del paso. El experimento sensible reduce el margen A entre frenado y pendiente. Para q = 0, ∂t_det/∂A = −v₀/A². Una variación pequeña en A puede cambiar mucho el tiempo estimado.",
        "Ejemplo de control. Para v₀ = 8 m/s, A = 2 m/s², q = 0 y reacción 1 s, se obtiene t_freno = 4 s y d_freno = 16 m. La parada completa tarda 5 s y abarca 24 m. Integrar una velocidad lineal reproduce exactamente esa distancia en aritmética exacta."
    ),
    "deterioro": (
        "¿Cuándo llega un indicador de desgaste a un umbral hipotético de inspección?",
        "D(t) = D₀ + αt + βt²;   f(t) = D(t) − D_umbral = 0.",
        "t es el tiempo en días. D es un indicador adimensional. α y β se expresan en día⁻¹ y día⁻². Los coeficientes, el umbral y la calibración son datos sintéticos. Se obtiene la raíz del modelo base para aislar el error de raíces del de calibración.",
        "Si β > 0 y Δ = D_umbral − D₀ > 0, la primera raíz positiva se puede evaluar como 2Δ/[α + √(α² + 4βΔ)]. Cuando β = 0 queda Δ/α, si α > 0. Para el sistema de calibración se define primero x* y se forma b = Ax*.",
        "La calibración usa A = I − (1−ε)uuᵀ con u = (1,1,1,1)ᵀ/2. Como u tiene norma 1, los autovalores son ε en la dirección u y 1 en su complemento. A es SPD para ε > 0. En el rango ε ≤ 1, κ₂(A) = 1/ε. El modo más sensible es el paralelo a u.",
        "Ejemplo de control. D₀ = 0,2, α = 0,1 día⁻¹, β = 0,01 día⁻² y umbral 1. Sustituir t = (−0,1 + √0,042)/0,02 da aproximadamente 5,24695 días. La raíz negativa no representa un instante futuro."
    ),
    "viento": (
        "¿Cómo cambian la trayectoria y la magnitud acumulada de la oscilación al variar viento, amortiguamiento y frecuencia?",
        "x′ = v;   v′ = [F₀ cos(ωt) − cv − kx]/m.",
        "x en m, v en m/s, masa m en kg, c en N·s/m, k en N/m, F₀ en N, ω en rad/s y tiempo en s. Se fija el estado inicial (x₀,v₀). Es un oscilador lineal de un grado de libertad con fuerza hipotética.",
        "En régimen subamortiguado, x = e⁻ᵍ[C₁ cos(ω_dt)+C₂ sin(ω_dt)] + a cos(ωt)+b sin(ωt), con g = ct/(2m) y ω_d² = k/m − (c/2m)². Si δ = k − mω² y d = cω, entonces a = F₀δ/(δ²+d²) y b = F₀d/(δ²+d²). Se ajustan C₁,C₂ al estado inicial.",
        "La magnitud acumulada J = ∫x² dt tiene unidades m²·s. El valor de referencia se obtiene integrando la trayectoria cerrada con cuadratura de Gauss-Legendre independiente. Se contrasta la cuadratura de 256 puntos con la de 128. La proximidad a resonancia y un amortiguamiento pequeño pueden elevar la sensibilidad de la respuesta estacionaria a ω.",
        "Control independiente sin viento ni amortiguamiento. Con m = k = 1, x₀ = 1 y v₀ = 0, se obtiene x(t) = cos t y J(0,π) = π/2. Esto permite verificar la escala de la posición y de la integral."
    ),
    "sensores": (
        "¿Cuánto se distorsiona una señal reconstruida al retirar registros o perturbar los nodos?",
        "y(t) = sin(t);   tᵢ = 6[i/(n−1)]ᵖ;   yᵢ = sin(tᵢ) + σ cos(2,3i).",
        "t en segundos, y en unidades normalizadas y η como perturbación sintética reproducible. Los tres interpolantes comparten exactamente el mismo conjunto de nodos. Los puntos intermedios reservados se comparan contra la señal limpia.",
        "Lagrange y Newton construyen el mismo polinomio en aritmética exacta. El spline cúbico natural impone continuidad de la función y sus dos primeras derivadas y segunda derivada nula en los extremos. El error de predicción se resume con RMSE sobre los puntos ocultos.",
        "La amplificación del polinomio ante perturbación de datos se estima mediante la suma de valores absolutos de funciones cardinales evaluada en los puntos ocultos. Se obtiene el máximo sobre ese conjunto discreto. Nodos agrupados pueden amplificar ruido en intervalos vacíos.",
        "Ejemplo de control. Con t = 0 y t = π/2, el interpolante lineal da y(π/4) = 0,5. La referencia es √2/2 y el error absoluto vale aproximadamente 0,207107. Un residuo nodal cero no implica error cero en puntos ocultos."
    ),
}
METHODS = [
    ("Sistemas lineales", "Jacobi", "x nuevo ← D⁻¹[b − (L+U)x anterior]. Cambiar todas las componentes a la vez."),
    ("Sistemas lineales", "Gauss-Seidel", "Actualizar fila a fila reutilizando inmediatamente las componentes nuevas."),
    ("Sistemas lineales", "LU", "Factorizar PA = LU y resolver Ly = Pb y Ux = y por sustitución."),
    ("Sistemas lineales", "Gradiente conjugado", "r ← b−Ax, p ← r; avanzar α = rᵀr/(pᵀAp), actualizar residuo y dirección. Requiere A SPD."),
    ("Raíces", "Bisección", "Evaluar el punto medio y conservar el subintervalo con cambio de signo."),
    ("Raíces", "Newton-Raphson", "t nuevo ← t − f(t)/f′(t). Controlar derivada pequeña y residuo."),
    ("Raíces", "Secante", "Usar dos semillas y reemplazar f′ por la pendiente de sus dos evaluaciones."),
    ("Integración", "Trapecio compuesto", "Combinar subintervalos uniformes ponderando los extremos por 1/2."),
    ("Integración", "Simpson 1/3", "Con n par, ponderar el interior alternando 4 y 2 y multiplicar por h/3."),
    ("Integración", "Romberg", "Refinar trapecio a la mitad y extrapolar con Rᵢⱼ = Rᵢ,ⱼ₋₁ + (Rᵢ,ⱼ₋₁ − Rᵢ₋₁,ⱼ₋₁)/(4ʲ−1)."),
    ("EDO", "RK2 punto medio", "k₁ ← f(t,y), k₂ ← f(t+h/2,y+hk₁/2); y nuevo ← y+hk₂."),
    ("EDO", "RK4 clásico", "Evaluar k₁,k₂,k₃,k₄ en extremo inicial, dos puntos medios y extremo final. Sumar h(k₁+2k₂+2k₃+k₄)/6."),
    ("Interpolación", "Lagrange", "Construir p(t) = Σ yᵢ ℓᵢ(t) con bases cardinales ℓᵢ(tⱼ)=δᵢⱼ."),
    ("Interpolación", "Newton", "Tabular diferencias divididas y evaluar la forma anidada del polinomio."),
    ("Interpolación", "Spline natural", "Resolver un sistema tridiagonal para segundas derivadas y evaluar cada cúbico en su intervalo."),
]
WEEK_TITLE={1:"Modelos y primeros algoritmos",2:"Integración y experimentos",3:"Informe final"}
def key(m):
    return m.get("name") or m.get("id") or "Método"

def shorten(s, lim):
    s=str(s)
    return s if len(s)<=lim else s[:lim-1].rstrip()+"…"

def len_trace(m):
    return len(m.get("iterations") or [])

def page_decor(version):
    def draw(c, doc):
        c.saveState()
        c.setTitle(f"SIMTELE-RISK | {WEEK_TITLE[version]}")
        c.setAuthor(STUDENT)
        c.setStrokeColor(LINE)
        c.line(48,H-39,W-48,H-39)
        c.line(48,42,W-48,42)
        c.setFont("BodyBold",8.3); c.setFillColor(TEAL)
        c.drawString(48,H-29,"SIMTELE-RISK  /  INF 373")
        c.setFont("Body",8); c.setFillColor(GRAY)
        c.drawRightString(W-48,H-29,WEEK_TITLE[version])
        c.drawString(48,27,STUDENT)
        c.drawRightString(W-48,27,f"{doc.page:02d}")
        c.restoreState()
    return draw

def title(label, heading, lead=None):
    p=[para(label,LABEL),para(heading,H1)]
    if lead: p.append(para(lead))
    return p

def cover(version):
    header="DESAFÍO INTEGRADOR FINAL   /   MÉTODOS NUMÉRICOS"
    panel=Table([
        [Paragraph(header,style("coverlabel",10,14,GOLD,True))],
        [Paragraph("SIMTELE-RISK",style("coverlarge",36,42,WHITE,True))],
        [Paragraph("Modelos numéricos para un sistema de transporte por cable",
                   style("covertitle",15,21,WHITE))],
    ],colWidths=[BODY_WIDTH])
    panel.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),NAVY),("LEFTPADDING",(0,0),(-1,-1),22),
        ("RIGHTPADDING",(0,0),(-1,-1),20),("TOPPADDING",(0,0),(-1,-1),15),
        ("BOTTOMPADDING",(0,0),(-1,-1),15),
    ]))
    return [
        Spacer(1,69),panel,Spacer(1,26),para(f"SEMANA {version:02d}",LABEL),
        para(WEEK_TITLE[version],H1),
        para("Universidad Mayor de San Andrés<br/>Facultad de Ciencias Puras y Naturales<br/>Carrera de Informática".replace("<br/>","\n")),
        Spacer(1,14),
        table(["Estudiante","Asignatura"],[[STUDENT,"INF 373 · Métodos Numéricos"]]),
        Spacer(1,9),para(TEACHER),para("Modalidad individual · Mención: Desarrollo de Software",SMALL),
        Spacer(1,27),para(
            "Caso educativo inspirado en Mi Teleférico, La Paz. Los escenarios y parámetros son sintéticos. "
            "El proyecto simula modelos matemáticos y carece de conexión con equipos o registros de operación.",SMALL
        ),PageBreak(),
    ]

def intro():
    return title("01   /   PROPÓSITO Y ALCANCE","Cuatro problemas, una aplicación") + [
        para("SIMTELE-RISK reúne doce experimentos reproducibles. Cada caso separa la referencia, el resultado "
             "numérico, la sensibilidad a perturbaciones y lo que el modelo permite concluir sobre el fenómeno."),
        para("Objetivo",H2),
        para("Comparar métodos numéricos mediante referencias analíticas o cuadraturas independientes, cuantificar el error y "
             "guardar las condiciones completas de cada ejecución para que otra persona pueda recuperarla y repetir el cálculo."),
        table(["Caso","Pregunta","Métodos"],[
            ["Detención","Tiempo y distancia total hasta detenerse","RK2, RK4, raíces e integración"],
            ["Deterioro","Días hasta el umbral de inspección","Raíces y sistemas SPD 4 × 4"],
            ["Viento","Desplazamiento y oscilación acumulada","RK2, RK4 y cuadraturas"],
            ["Sensores","Predicción en instantes reservados","Lagrange, Newton y spline natural"],
        ],[.9,1.52,1.24]),
        para("Diseño de los experimentos",H2),
        para("Normal usa la configuración base. Estrés modifica los supuestos físicos o la exigencia del cálculo. "
             "Mal condicionado incorpora una perturbación cuyo efecto se mide. Una simulación sensible puede converger, "
             "y una ejecución que no converge por presupuesto de pasos puede estar bien condicionada."),
        para("Teoría de errores",H2),
        equation("Error absoluto = |aproximado − referencia|.   Error relativo = error absoluto / |referencia|.   Error porcentual = 100 · error relativo."),
        Spacer(1,7),
        para("Para vectores se usan normas o métricas indicadas por la ejecución. Si la referencia es cero, se omite el cociente. "
             "El residuo verifica la ecuación satisfecha, por ejemplo ||b−Ax|| en calibración. Una solución puede tener "
             "residuo pequeño y error alto si la matriz amplifica perturbaciones."),
        para("Para sensibilidad se compara el cambio de salida con la perturbación de entrada. Cada fila debe interpretarse "
             "según las unidades de la entrada y la salida. El cociente adimensional, cuando procede, compara cambios relativos."),
        PageBreak(),
    ]

def params_text(p):
    return "  ·  ".join(f"{k} = {fmt(v,4)}" for k,v in p.items())

def headline(result):
    r=result["reference"]
    cid=result["caseId"]
    if cid=="detencion":
        return f"Tiempo total {fmt(r['detencion_total_s'])} s\nDistancia {fmt(r['detencion_total_m'])} m\nMargen {fmt(r['margen_m'])} m"
    if cid=="deterioro":
        return f"Umbral {fmt(r['umbral_dias'])} días\nCon retraso D={fmt(r['deterioro_con_retraso'])}\nκ₂(A)={fmt(r['condicion_2'])}"
    if cid=="viento":
        return f"Pico muestreado {fmt(r['pico_m_malla_2048'])} m\nJ={fmt(r['J_m2_s'])} m²·s\nEstado final x={fmt(r['desplazamiento_final_m'])} m"
    return f"sin(t) sin ruido\n{len(r['nodos'])} nodos · {len(r['ocultos'])} puntos ocultos\nRMS limpio={fmt(r['RMS_senal_en_prueba'])}"

def scenario_rows(runs):
    return [[S_LABEL[r["scenarioId"]],params_text(r["params"]),headline(r)] for r in runs]

def model_page(cid,runs,idx,chart_policy="normal"):
    q,eq,units,ref,sense,example=MODELS[cid]
    first=runs[0]
    arr=title(f"{idx:02d}   /   MODELO Y EVIDENCIA",TITLE[cid],q)
    arr.extend([equation(eq),Spacer(1,7),para(units),para("Referencia y supuestos",H2),para(ref)])
    if runs:
        arr.extend([
            para("Configuración reproducible",H2),
            table(["Escenario","Entradas del motor","Referencia"],scenario_rows(runs),[.82,2.78,1.25]),
            Spacer(1,7),
        ])
    if first.get("charts"):
        arr.extend([Plot(c,153) for c in first["charts"][:1]])
        arr.extend([para("Figura. Solución o reconstrucción del escenario Normal.",SMALL)])
    arr.append(PageBreak())
    return arr

def error_rows(runs):
    rows=[]
    for r in runs:
        for m in r.get("methods",[]):
            rows.append([
                S_LABEL[r["scenarioId"]] if m is r["methods"][0] else "",
                key(m),shorten(fmt(m.get("value"),4),71),fmt(m.get("errorAbs"),4),
                fmt(m.get("errorRel"),3),fmt(m.get("residual"),3),
                str(len_trace(m)),
                fmt(m.get("converged")),
            ])
    return rows

def error_table(runs):
    return table(["Escenario","Método","Valor / vector","E. abs.","E. rel.","Residuo","Filas","Conv."],
                 error_rows(runs),[1.06,1.65,1.65,.77,.77,.76,.51,.55])

def step_text(row):
    fields=[(k,v) for k,v in row.items() if k not in {"n","x","residual","errorAbs","errorRel"}]
    return shorten(" · ".join(f"{k}={fmt(v,3)}" for k,v in fields if v is not None),92)

def trace_rows(m):
    rows=m.get("iterations") or []
    if not rows: return []
    indices=[0] if len(rows)==1 else ([0,1,len(rows)-1] if len(rows)>2 else [0,len(rows)-1])
    return [[key(m) if i==0 else "",str(rows[i].get("n",i)),shorten(fmt(rows[i].get("x"),4),82),
             fmt(rows[i].get("residual"),4),fmt(rows[i].get("errorAbs"),4)] for i in indices]

def cond_text(r):
    items=r.get("sensitivity") or []
    if not isinstance(items,list): return str(items)
    parts=[]
    for s in items:
        txt=str(s.get("label","Perturbación"))
        for k,lab in [("deltaInput","Δ entrada"),("deltaOutput","Δ salida"),("amplification","amplificación")]:
            if s.get(k) is not None:
                txt+=f" · {lab} {fmt(s[k],4)}{(" " + s.get("inputUnit", "")) if k=="deltaInput" else (" " + s.get("outputUnit", "")) if k=="deltaOutput" else ""}"
        parts.append(txt)
    return "\n".join(parts)

def result_page(cid,runs,idx):
    arr=title(f"{idx:02d}   /   RESULTADOS POR ESCENARIO",TITLE[cid])
    arr.extend([error_table(runs),Spacer(1,6),para(
        "Conv. indica el estado registrado por el método. Filas cuenta los registros de iteración o refinamiento, "
        "incluida la fila inicial cuando existe. n/a indica que la métrica no procede. El porcentaje se obtiene como 100 × E. rel. En sensores el relativo se normaliza por el RMS de la señal limpia de prueba. En RK, Conv. verifica precisión de trayectoria al final de una malla fija.",SMALL)])
    arr.append(PageBreak())
    return arr

def trace_page(cid, runs, idx):
    arr=title(f"{idx:02d}   /   TRAZAS Y CRITERIOS","Cómo se verificó cada método")
    normal=runs[0]
    tr=[]
    settings=[]
    for m in normal["methods"]:
        s=m["settings"]
        steps = [("h","step"),("τ","tolerance"),("máx.","maxIter"),("intervalo","interval"),("semillas","seeds")]
        cfg=" · ".join(f"{label}={fmt(s[k],3)}" for label,k in steps if s.get(k) is not None)
        settings.append([key(m),cfg,s["stop"]])
        rows=m["iterations"]
        if not rows: continue
        for i in dict.fromkeys([0,len(rows)-1]):
            r=rows[i]
            coordinate=r.get("t",r.get("subintervalos",r.get("h",r.get("n"))))
            tr.append([key(m) if i==0 else "",fmt(coordinate,4),shorten(fmt(r.get("x"),4),68),
                       fmt(r.get("errorAbs"),4),fmt(r.get("residual"),4)])
    arr.extend([
        para("Escenario Normal. Se muestran el primer y el último registro de cada método. La interfaz y el JSON de "
             "la ejecución conservan todas las filas para cada escenario.",SMALL),
        table(["Método","t / nivel","Aproximación","E. abs.","Residuo"],tr,[1.47,.70,1.7,.8,.8]),
        para("Configuración y criterio",H2),
        table(["Método","Entradas de control","Parada / verificación"],settings,[1.01,1.22,2.12]),
        PageBreak(),
    ])
    return arr

def discussion_page(cid,runs,idx):
    q,eq,units,ref,sense,example=MODELS[cid]
    normal,stress,mal=runs
    arr=title(f"{idx:02d}   /   LECTURA DE RESULTADOS","Precisión, sensibilidad y significado")
    chart_run=stress if cid in {"detencion","viento"} else mal
    charts=chart_run.get("charts",[])
    if len(charts)>1: arr.extend([Plot(charts[-1],143),para("Figura. "+S_LABEL[chart_run["scenarioId"]]+".",SMALL)])
    arr.extend([para("Sensibilidad del escenario mal condicionado",H2),para(sense,SMALL)])
    for r in runs[-1:]:
        if cond_text(r): arr.append(para(S_LABEL[r["scenarioId"]]+". "+cond_text(r),SMALL))
    arr.extend([
        para("Conclusión numérica",H2),
        para(normal.get("numericalConclusion","")),
        para("Estrés. "+str(stress.get("numericalConclusion","")),SMALL),
        para("Mal condicionado. "+str(mal.get("numericalConclusion","")),SMALL),
        para("Conclusión sobre el problema",H2),
        para(normal.get("physicalConclusion","")),
        para("Estrés. "+str(stress.get("physicalConclusion","")),SMALL),
        para("Mal condicionado. "+str(mal.get("physicalConclusion","")),SMALL),
        PageBreak(),
    ])
    return arr
def data_pages(persistence):
    t=title("ARQUITECTURA   /   PERSISTENCIA","De los parámetros a un historial verificable")
    t.extend([
        para("La interfaz web ofrece cuatro casos y un historial común. El motor JavaScript ejecuta modelos y métodos. "
             "El servidor HTTP de Node registra en SQLite las entradas efectivas, las trazas y una copia íntegra del resultado."),
        DER(),
        para("Figura. DER de la versión final. simulacion.repeticion_de enlaza una repetición con su ejecución de origen.",SMALL),
        table(["Relación","Clave / contenido"],[
            ["caso_estudio","id (PK), nombre, modelo_version."],
            ["escenario","id (PK), caso_id (FK), tipo, parametros_json, fuente_datos."],
            ["simulacion","id (PK), escenario_id (FK), fecha, usuario, estado, versión y resultado íntegro. "
                          "repeticion_de (FK) y verificacion_json cuando corresponde."],
            ["ejecucion_metodo","id (PK), simulacion_id (FK), método, tolerancia, paso, máximo, convergencia, tiempo opcional y configuración."],
            ["iteracion_resultado","(ejecucion_id, numero) (PK), aproximación, residuo, errores y registro íntegro."],
            ["resultado_resumen","ejecucion_id (PK y FK), referencia, valor, métricas e interpretación."],
        ],[1.12,2.95]),
        Spacer(1,7),para("La escritura de una simulación y sus filas relacionadas ocurre en una transacción. "
                           "Los parámetros y valores no aplicables permanecen explícitos. Ver schema.sql y docs/DER.md.",SMALL),
        PageBreak(),
    ])
    t.extend(title("VERIFICACIÓN   /   REINICIO","Guardar, recuperar y repetir"))
    t.extend([
        table(["Paso","Acción verificable"],[
            ["01","Seleccionar caso, escenario y parámetros. Ejecutar y guardar; registrar el identificador devuelto."],
            ["02","Cerrar y reiniciar el servidor con el mismo archivo SQLite."],
            ["03","Abrir el historial y recuperar por identificador. Inspeccionar parámetros, trazas y series del gráfico."],
            ["04","Relanzar. Comparar estructura y valores de la nueva salida con el registro anterior."],
        ],[.43,3.5]),
        para("Criterio de coincidencia",H2),
        equation("|a − b| ≤ 10⁻¹⁰ × máx(1, |a|, |b|)."),
        Spacer(1,7),
        para("También se comprueban los datos no numéricos y la estructura. Las dos ejecuciones se conservan vinculadas."),
    ])
    if persistence:
        t.extend([para("Resultado observado",H2),para(persistence)])
    else:
        t.append(para("Prueba reproducible incluida en el repositorio. Ejecutar la suite sobre un archivo temporal para comprobar este flujo.",SMALL))
    return t

def references():
    return [
        para("Referencias y anexos",H2),
        para("Consigna oficial SIMTELE-RISK, Métodos Numéricos. Fuente de requisitos, escenarios y entregables.",SMALL),
        para("Burden, R. L., Faires, J. D. y Burden, A. M. Numerical Analysis. 10.ª ed. Cengage. "
             "Métodos iterativos, interpolación, cuadratura y EDO.",SMALL),
        para("Documentación SQLite: claves externas, transacciones y SQL. https://www.sqlite.org/docs.html",SMALL),
        para("Proyecto local: http://127.0.0.1:8765 después de iniciar el servidor. "
             "README.md, schema.sql, docs/DER.md y tests/ acompañan esta entrega. Los enlaces públicos de aplicación "
             "y repositorio se añaden tras su publicación.",SMALL),
    ]

def methods_pages():
    p=title("MÉTODOS   /   PSEUDOCÓDIGO","Cómo se obtienen los resultados")
    p.extend([table(["Familia","Método","Paso esencial"],METHODS,[.9,1.05,2.6]),PageBreak()])
    return p

def validation(grouped):
    p=title("PRUEBAS   /   CONTROLES INDEPENDIENTES","Comprobaciones analíticas")
    for c in CASES:
        p.extend([para(TITLE[c],H2),para(MODELS[c][-1])])
    p.extend([
        para("Comprobación de convergencia y condición",H2),
        para("La calibración SPD usa autovalores positivos. Para ε ∈ (0,1], la fila diagonal de A "
             "vale (3+ε)/4 y la suma de magnitudes fuera de la diagonal vale 3(1−ε)/4. "
             "La diferencia ε explica la dominancia estricta de filas. Jacobi y Gauss-Seidel convergen en "
             "aritmética exacta, pero su lentitud puede agotar el presupuesto. GC explota la estructura SPD; "
             "LU resuelve mediante eliminación y sustituciones."),
        para("Estas comprobaciones son derivaciones reproducibles. Las pruebas automáticas de la carpeta tests/ "
             "ejercitan el motor y la persistencia con las entradas del proyecto.",SMALL),
        PageBreak(),
    ])
    return p

def week_one(grouped, persistence):
    pages=cover(1)+intro()
    pages.extend(title("MODELOS   /   SEMANA 01","Formulación de los cuatro casos"))
    for c in CASES:
        q,eq,units,ref,sense,example=MODELS[c]
        pages.extend([para(TITLE[c],H2),equation(eq),Spacer(1,5),para(units,SMALL)])
    pages.extend([para("El modelo sintético y las doce configuraciones se detallan en el informe final.",SMALL),PageBreak()])
    runs=grouped["deterioro"]
    pages.extend(title("SISTEMAS LINEALES   /   EVIDENCIA","Calibración SPD de orden cuatro"))
    pages.extend([
        equation(MODELS["deterioro"][3]),Spacer(1,6),
        para("Ejemplo manual. Con ε = 0,55, las entradas diagonales valen 0,8875 y las entradas fuera "
             "de la diagonal valen −0,1125. Si z* = [0,15; 0,30; 0,35; 0,02], entonces "
             "A z* = [0,05775; 0,20775; 0,25775; −0,07225]. Los autovalores de A son 0,55 y 1 "
             "(multiplicidad tres), por lo que κ₂ ≈ 1,81818."),
        table(["Escenario","ε","κ₂(A)","Máx. iteraciones"],[
            [S_LABEL[r["scenarioId"]],fmt(r["params"]["epsilon"]),fmt(1/r["params"]["epsilon"]),fmt(r["params"]["maxIter"])] for r in runs
        ]),
        para("Comparación con las soluciones conocidas",H2),
    ])
    linear = [
        dict(r, methods=[m for m in r["methods"] if any(k in key(m).lower() for k in ("jacobi","seidel","conjug","lu"))]) for r in runs
    ]
    pages.extend([error_table(linear),Spacer(1,6),para(
        "El ejemplo manual fija el cuarto coeficiente en 0,02 para ilustrar la multiplicación. Las tablas se "
        "generan con los cuatro coeficientes que usa el motor en cada escenario.",SMALL),
        PageBreak()])
    pages.extend(title("DISEÑO   /   PRIMER AVANCE","Escenarios y DER"))
    pages.extend([
        table(["Caso","Normal","Estrés","Mal condicionado"],[
            ["Detención","Freno constante","Arrastre y reacción mayor","Cancelación entre frenado y pendiente"],
            ["Deterioro","Tasas base","Tasas y retraso mayores","Modo de calibración débil"],
            ["Viento","Vibración libre","Fuerza periódica","Frecuencia próxima a la natural"],
            ["Sensores","Nodos uniformes","Medición con ruido","Nodos agrupados"],
        ],[.74,1,1,1.2]),Spacer(1,10),DER(),
        para("El esquema distingue la configuración, la ejecución y su evidencia. La interfaz muestra cuatro casos "
             "y el historial reúne los experimentos guardados.",SMALL),
    ]+references())
    return pages

def week_two(grouped,persistence):
    pages=cover(2)+methods_pages()
    for c in CASES:
        runs=grouped[c]
        pages.extend(title("EXPERIMENTOS   /   SEMANA 02",TITLE[c]))
        pages.extend([table(["Escenario","Entradas","Referencia"],scenario_rows(runs),[.85,2.8,1.23]),Spacer(1,7)])
        charts=runs[0].get("charts") or []
        for ch in charts[:1]+charts[-1:] if len(charts)>1 else charts:
            pages.extend([Plot(ch,110),Spacer(1,6)])
        pages.extend([para("Primer contraste",H2),para(runs[1].get("numericalConclusion",""),SMALL),
                      para(runs[2].get("numericalConclusion",""),SMALL),

                      PageBreak()])
    pages.extend(title("INTEGRACIÓN   /   VALIDACIÓN","Persistencia y fallos detectados"))
    pages.extend([
        para("Guardar, reiniciar el servidor, abrir el historial y repetir la simulación con las mismas entradas. "
             "La coincidencia se comprueba en parámetros, trazas, resultados y series con tolerancia relativa y absoluta combinada."),
        para(persistence if persistence else "La prueba ejecutable documenta el procedimiento de reinicio y recuperación."),
        para("Casos que requieren atención",H2),
        para("Un iterativo puede agotar pasos al disminuir el autovalor del modo débil. Los errores de interpolación "
             "deben comprobarse en puntos reservados porque los nodos pueden coincidir incluso con una predicción deficiente. "
             "Se validan dominios y parámetros antes de ejecutar."),
        para("Consultar la documentación de ejecución y persistencia en README.md y docs/DER.md.",SMALL),
    ]+references())
    return pages

def final_report(grouped,persistence):
    pages=cover(3)+intro()+methods_pages()+validation(grouped)
    idx=2
    for c in CASES:
        runs=grouped[c]
        pages.extend(model_page(c,runs,idx)); idx+=1
        pages.extend(result_page(c,runs,idx)); idx+=1
        pages.extend(trace_page(c,runs,idx)); idx+=1
        pages.extend(discussion_page(c,runs,idx)); idx+=1
    pages.extend(data_pages(persistence))
    pages.extend([PageBreak()]+title("CIERRE   /   DEFENSA","Qué muestran los doce experimentos"))
    pages.extend([
        para("Conclusión integradora",H2),
        para("Las referencias separan errores de discretización, redondeo y sensibilidad del modelo. En detención, "
             "una desaceleración casi cancelada aumenta la respuesta a perturbaciones. En deterioro, la calibración débil "
             "puede producir coeficientes inciertos. En viento, la proximidad a resonancia modifica la sensibilidad física. "
             "En sensores, el espaciamiento de nodos gobierna cuánto se transmite el ruido a los intervalos sin muestras."),
        para("Aporte desde Desarrollo de Software",H2),
        para("Diseño de un motor desacoplado de la interfaz, API de historial y persistencia transaccional. "
             "El modelo relacional permite inspeccionar una aproximación individual y la copia íntegra permite reproducir "
             "la comparación gráfica y la interpretación que vio la persona usuaria."),
        para("Límites",H2),
        para("Los parámetros son sintéticos y el sistema es de carácter educativo. El resultado depende de las hipótesis, "
             "del intervalo simulado y de las referencias. Los modelos no representan un dictamen de seguridad "
             "ni una predicción sobre la infraestructura real."),
        para("Secuencia de defensa",H2),
        para("Elegir un caso, ejecutar Normal y cambiar un parámetro con unidad. Comparar un error con su referencia. "
             "Abrir la condición sensible y explicar la diferencia entre sensibilidad y convergencia. "
             "Guardar, recuperar y relanzar una simulación. Exponer una conclusión de método y otra del fenómeno."),
    ]+references())
    return pages

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--datos",type=Path,required=True,help="JSON de las doce ejecuciones del motor")
    parser.add_argument("--persistencia",type=Path,help="Texto de la prueba de reinicio y recuperación")
    parser.add_argument("--salida",type=Path,default=ROOT/"entrega")
    args=parser.parse_args()
    rows=json.loads(args.datos.read_text(encoding="utf-8-sig"))
    index={(r["caseId"],r["scenarioId"]):r for r in rows}
    grouped={c:[index[c,s] for s in SCENARIOS] for c in CASES}
    persistence=args.persistencia.read_text(encoding="utf-8-sig").strip() if args.persistencia else ""
    args.salida.mkdir(parents=True,exist_ok=True)
    for v,func,name in [
        (1,week_one,"Semana_1_Avance_SIMTELE-RISK.pdf"),
        (2,week_two,"Semana_2_Experimentos_SIMTELE-RISK.pdf"),
        (3,final_report,"Informe_final_SIMTELE-RISK.pdf"),
    ]:
        doc=SimpleDocTemplate(str(args.salida/name),pagesize=A4,leftMargin=42,rightMargin=42,topMargin=57,bottomMargin=58,
                              title=f"SIMTELE-RISK | {WEEK_TITLE[v]}",author=STUDENT)
        decor=page_decor(v)
        doc.build(func(grouped,persistence),onFirstPage=decor,onLaterPages=decor)
        print(doc.filename)

if __name__=="__main__":
    main()
