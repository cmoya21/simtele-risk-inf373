# Regenerar los informes de SIMTELE-RISK

Los PDF se construyen con los valores, trazas y gráficos de las doce ejecuciones de `math.mjs`. Desde la raíz, con Node.js, Python y ReportLab instalados:

```text
node docs/exportar_informes.mjs experimentos.json
python docs/generar_informes.py --datos experimentos.json --persistencia docs/verificacion_informes.txt
```

Los archivos se guardan en `entrega/`. La entrada de persistencia es un registro de las verificaciones efectuadas con esta versión del proyecto.
