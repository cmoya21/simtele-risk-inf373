import { cases, run } from '../math.mjs';
import { writeFileSync } from 'node:fs';

const output = process.argv[2];
if (!output) throw Error('Uso: node docs/exportar_informes.mjs archivo.json');
const rows = cases.flatMap(({id, scenarios}) =>
  Object.keys(scenarios).map(scenario => run(id, scenario)));
writeFileSync(output, JSON.stringify(rows, null, 2), 'utf8');
console.log(`${rows.length} ejecuciones exportadas`);
