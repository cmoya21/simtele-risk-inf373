import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createStore } from './store.mjs';

const publicDir = fileURLToPath(new URL('./public',import.meta.url));
const mathFile = fileURLToPath(new URL('./math.mjs',import.meta.url));
const mime = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8',
  '.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8',
  '.svg':'image/svg+xml','.png':'image/png','.json':'application/json; charset=utf-8'};

function send(res,status,body) {
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(JSON.stringify(body));
}

async function readBody(req) {
  const parts=[];
  let size=0;
  for await (const chunk of req) {
    size+=chunk.length;
    if(size>16384) throw new Error('Entrada demasiado grande.');
    parts.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(parts).toString('utf8')); }
  catch { throw new Error('El cuerpo debe ser un objeto JSON válido.'); }
}

export function makeServer(dbPath) {
  const store=createStore(dbPath);
  const server=createServer(async(req,res)=>{
    try {
      const url=new URL(req.url,'http://localhost');
      const path=decodeURIComponent(url.pathname);
      res.setHeader('X-Content-Type-Options','nosniff');
      if(path==='/api/simulaciones') {
        if(req.method==='GET') return send(res,200,store.list(url.searchParams.get('q')?.slice(0,100) ?? ''));
        if(req.method==='POST') {
          const body=await readBody(req);
          const {caseId,scenarioId,overrides={}}=body ?? {};
          if(typeof caseId!=='string' || typeof scenarioId!=='string' ||
            !overrides || typeof overrides!=='object' || Array.isArray(overrides)) {
            return send(res,400,{error:'Indica caso, escenario y parámetros válidos.'});
          }
          return send(res,201,store.execute(caseId,scenarioId,overrides));
        }
      }
      const entry=path.match(/^\/api\/simulaciones\/([0-9a-f-]{36})(\/repetir)?$/);
      if(entry) {
        const result=entry[2] && req.method==='POST' ? store.repeat(entry[1])
          : !entry[2] && req.method==='GET' ? store.open(entry[1]) : null;
        return result ? send(res,entry[2]?201:200,result) : send(res,404,{error:'Simulación no encontrada.'});
      }
      if(path.startsWith('/api/')) return send(res,404,{error:'Ruta desconocida.'});
      if(req.method!=='GET' && req.method!=='HEAD') return send(res,405,{error:'Método no permitido.'});
      const file=path==='/math.mjs' ? mathFile : resolve(publicDir,'.'+(path==='/'?'/index.html':path));
      if(file!==mathFile && !file.startsWith(publicDir+sep)) return send(res,404,{error:'Archivo no encontrado.'});
      try {
        const bytes=await readFile(file);
        res.writeHead(200,{'Content-Type':mime[extname(file)] ?? 'application/octet-stream'});
        res.end(req.method==='HEAD' ? undefined : bytes);
      } catch(error) {
        if(['ENOENT','EISDIR','ENOTDIR'].includes(error.code)) return send(res,404,{error:'Archivo no encontrado.'});
        throw error;
      }
    } catch(error) {
      if(error.code?.startsWith('ERR_SQLITE')) {
        console.error(error);
        return send(res,500,{error:'No se pudo guardar o recuperar la ejecución.'});
      }
      return send(res,400,{error:error.message});
    }
  });
  server.on('close',()=>store.close());
  return server;
}

if(process.argv[1] && pathToFileURL(resolve(process.argv[1])).href===import.meta.url) {
  const dbPath=process.env.SIMTELE_DB ?? fileURLToPath(new URL('./data/simtele.sqlite',import.meta.url));
  const port=Number(process.env.PORT ?? 8765);
  const host=process.env.SIMTELE_HOST ?? '127.0.0.1';
  const server=makeServer(dbPath);
  server.listen(port,host,()=>console.log('SIMTELE-RISK · http://'+host+':'+server.address().port));
  for(const signal of ['SIGINT','SIGTERM']) process.on(signal,()=>server.close());
}
