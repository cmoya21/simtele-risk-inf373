import { mkdir, readFile, writeFile, copyFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url));
const out=resolve(process.argv[2] ?? join(root,'dist'));
await mkdir(out,{recursive:true});
const source=(name)=>readFile(join(root,name),'utf8');
const copy=(from,to=from)=>copyFile(join(root,from),join(out,to));

const html=(await source('public/index.html'))
  .replace('href="/styles.css"','href="./styles.css"')
  .replace('<script type="module" src="/app.mjs"></script>',
    '<script defer src="./sql-wasm-browser.js"></script>\n  <script type="module" src="./app.mjs"></script>');
const app=(await source('public/app.mjs'))
  .replace("from '/math.mjs';","from './math.mjs';\nimport { browserApi } from './store-browser.mjs';")
  .replace(/async function api\(path, body\) \{[\s\S]*?\n\}(?=\nasync function saveResult)/,'const api = browserApi;')
  .replace('PERSISTENCIA · SQLITE','SQLITE · ESTE NAVEGADOR')
  .replace('Abre una ejecución con sus entradas, gráficos e iteraciones, o relánzala para comprobar la coincidencia del cálculo.',
    'Los experimentos se guardan en SQLite dentro de este navegador. Abre uno o relánzalo para comparar sus resultados.');
if(!html.includes('./sql-wasm-browser.js')||!app.includes('const api = browserApi;')||!app.includes("from './math.mjs';")) {
  throw new Error('No se pudo adaptar la aplicación a GitHub Pages.');
}
await Promise.all([
  writeFile(join(out,'index.html'),html),
  writeFile(join(out,'app.mjs'),app),
  writeFile(join(out,'.nojekyll'),''),
  copy('public/styles.css','styles.css'),
  ...['math.mjs','schema.sql','store-core.mjs','store-browser.mjs'].map(name=>copy(name)),
  copy('vendor/sql.js/sql-wasm-browser.js','sql-wasm-browser.js'),
  copy('vendor/sql.js/sql-wasm-browser.wasm','sql-wasm-browser.wasm'),
  copy('vendor/sql.js/LICENSE','LICENSE-sql.js.txt')
]);
console.log(out);
